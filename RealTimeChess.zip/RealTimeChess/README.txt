Alex Ngo
Andrew Lai
Areg Nersisyan
David Sun
Issac Fu

2/22/17

						CS 48 - Real Time Chess - Read Me 

Introduction:

	The program, Real Time Chess, is a multiplayer game that is meant to increase your ability to think and react fast. 
	And to get better at critical thinking and solving changing problems.
	It doesn't solve a problem its just meant for spending time with friends and trying to win against them.
	Its a great way to cure boredom. Get to pick who to play against and whether to be white pieces or black ones.
	Since there are no turns in this chess game, each second the players must think of what actions to take with their
	pieces and at the same time pay attention to the enemy s pieces.

Directions to run:
	Through eclipse you can also manually run it by first opening the RealTimeChess class then using the green run button at the top left button.
	
	Finally there is another way to run this but there's a bug that makes the program fail to load some images properly. If you're running this
	from a terminal, cd into the root directory (RealTimeChess), and simply type in ant -p. This will display all of the things the build.xml
	file can do. Then you can simply type in ant run to run the program. 

Instructions:

	Game starts off as regular chess. whites on the bottom and blacks on the top. Each player controlling their pieces.
	Unlike regular chess, there are no turns each player is free to move the pieces freely. That said each piece then
	cannot be moved for some time. That concept is called cooldowns, and all pieces have a 8 second timer.

How to Play:

	Left Click: First time, if on a piece it will be selected. Then clicking on an empty valid space it will be moved.
	Clicking on enemy piece that can be attacked will take over the piece. Clicked in invalid location, will not move
	piece but won't deselect it either.
	
	Right Click: Cancel a current selection.


	RULES:

		- Each chess piece can only be moved in its classical ways.

		- When a King is checked then rest of the game stops until its resolved.

Classes:

	GameBoard: Includes the main method.
	GraphicsBoard: Where the graphical part is made.
	Player: Where the game engine is.
	RealTimeChess: The main that controls the game
	TimerClock: Our designed clock to keep track of cooldowns.
	StartScreen: The window meant for the networking.
	Rules: Panel for rules
	Window: Window thats a JFrame, simply a window.
	Client: client class, connects to the server
	Server: server class, hosts the game, has the client connected
	ChessPiece: General class from which the rest of the pieces extend. Has most of the general functionality of each piece.
	King: Handles the specific cases of how the King functions.
	Queen: Handles the specific cases of how the Queen functions.
	Bishop: Handles the specific cases of how the Bishop functions.
	Knight: Handles the specific cases of how the Knight functions.
	Rook: Handles the specific cases of how the Rook functions.
	Pawn: Handles the specific cases of how the Pawn functions.
	Square: actual square pieces are stored in, gameboard made up by 8x8 array of these
	CoolDownAnimation: handles the cooldown animation of pieces after they move
	SoundEffect: Add sound for pieces
	Test: Not our coded class, found on stack overflow and will be used to do cooldown animations.

Some other comments (Known bugs)

If the network is slow then pieces will not update fast enough leading to a desync between the two boards, this is purely a network problem. 
In the future we may convert to a server -> client, client scheme so the server validates the moves.


Todos:
Chat
Adding visual timers to the game
Some other comments


JavaDoc located at:
https://ngonalex.github.io/
