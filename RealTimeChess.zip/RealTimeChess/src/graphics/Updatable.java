package graphics;

public interface Updatable {
	public void update();
}
