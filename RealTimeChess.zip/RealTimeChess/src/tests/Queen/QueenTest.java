package tests.Queen;

import game.*;

public class QueenTest {
	GameBoard testGameBoard;
	
	public QueenTest() {
		testGameBoard = new GameBoard(0);
	}
}
