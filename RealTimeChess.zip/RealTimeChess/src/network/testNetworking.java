package network;
import java.io.*;
import java.net.*;

public class testNetworking {
	public static void main(String [] args) throws 
	 UnknownHostException, IOException{
		//Server Host = new Server();
		Client me = new Client("127.0.0.1");
	}
}
